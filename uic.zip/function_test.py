import CloudStack
from time import sleep
import threading
import base64
import random


api = 'http://10.12.246.44:8080/client/api'
apikey = 'WCvvfpK1LuzdLxPEAHxheG0IVCIzNHdVRsNlT078kb5kg9yWutlBmF4atoDmA04pVsFyO8IiwpMINEtr-vEfnQ'
secret = 'LQWzMyPSycLcJ4rR1dfqbnlJ5hx8v9ylr18toNgC3FpjDERmN7Qs6PYZDOX8BpPISpCbF03PdAAxcs_452GhSA'
cloudstack = CloudStack.Client(api, apikey, secret)
# vms = cloudstack.listVirtualMachines()
# disks = cloudstack.listVolumes()
# hosts = cloudstack.listHosts()
# networks = cloudstack.listNetworks()
# print(vms)
# print(disks)

'''
vms = cloudstack.listVirtualMachines({"zoneid":"7327e4c4-3b7e-408e-a7f2-eec586ec93ee"})
'''
class Function_Test() :

    def __init__(self):

        # Flag indicating that the job is complete
        self.success = -1

        # Testing vm info
        self.vm = []

        # Testing volume id For volume check
        self.volumeidForCheck = 'e7efbc4c-4b43-4d8e-83a6-a3c391b7d94e'

        # Testing service offering id for scale check
        self.ServiceofferingidForScaleCheck = 'a9e95433-db99-4482-b298-bddd58167cd9'

        # Testing volume id for revert
        self.volumeidForRevert = 'ef5d81cf-66ca-41f5-9a2c-da8e38581080'


        # Deploying VM info
        self.zoneid = 'fa932031-f9c0-4e31-b945-2e0a2e3a8f25'
        self.serviceofferingid = '5c54d08c-1064-4ee3-ae62-e0b506f4ceec'
        self.templateid = '6a7a7b90-053a-4e6a-aab7-389f491ce92c'
        self.networkids = '60c2f961-403c-4e57-9cf5-7c0204ff3ded'


    def setZoneId(self, zoneid):
        self.zoneid = zoneid

    def setServiceofferingId(self, serviceofferingid):
        self.serviceofferingid = serviceofferingid

    def setZoneId(self, templateid):
        self.templateid = templateid

    def setNetworkId(self, networkids):
        self.networkids = networkids


    def setVolumeIdForCheck(self, volumeidForCheck):
        self.volumeidForCheck = volumeidForCheck

    def setServiceOfferingIdForScaleCheck(self, ServiceofferingidForScaleCheck):
        self.ServiceofferingidForScaleCheck = ServiceofferingidForScaleCheck

    def setVolumeidForRevert(self, volumeidForRevert):
        self.volumeidForRevert = volumeidForRevert


    def checkJobStatus(self, jobid, checkCount):

        # check if the job was successful
        jobResults = cloudstack.queryAsyncJobResult({'jobid': jobid})

        print(jobResults)

        if checkCount >= 20:
            print("FAIL")
            self.success = 0
            return

        if jobResults['jobstatus'] == 0:
            print("PENDING")
            threading.Timer(12, self.checkJobStatus, [jobid, checkCount + 1]).start()

        elif jobResults['jobstatus'] == 2:
            self.jobresult = jobResults['jobresult']
            print("ERROR")
            print(jobresult['errortext'])
            self.success = 0
            return

        elif jobResults['jobstatus'] == 1:
            print("SUCCESS")
            self.success = 1
            return



    def deployVM(self):
        user_data = 'echo "dhclient eth1" >> /etc/rc.local'
        utf = user_data.encode("UTF-8")
        encoded_data = base64.b64encode(utf)

        print("========== Deploying VM ==========")

        # deploy vm
        try:
            res = cloudstack.deployVirtualMachine({'serviceofferingid': self.serviceofferingid,
                                                        'templateid': self.templateid,
                                                        'zoneid': self.zoneid,
                                                        'networkids': self.networkids,
                                                        'userdata': encoded_data})
            print(res)

            # check if deployment was successful
            self.checkJobStatus(res['jobid'], 0)

            while self.success < 0:
                continue

            if self.success:
                self.success = -1

                jobResults = cloudstack.queryAsyncJobResult({'jobid': res['jobid']})
                jobResult = jobResults['jobresult']

                self.vm = jobResult['virtualmachine']

                nic = self.vm['nic']

                print('')
                print("========== test vm's information ==========")
                print('vm displayname: ' + self.vm['displayname'])
                print('vm state: ' + self.vm['state'])
                print('vm id: ' + self.vm['id'])
                print('vm ha eanble: ' + str(self.vm['haenable']))
                print('vm networkid: ' + nic[0]['networkid'])
                print('vm password: ' + self.vm['password'])
                print('')


        except KeyError as e:
            print("FAIL to call deployVirtualMachine", e)


    def distroyVM(self):
         # destroy vm
        print("\n========== Destroying VM ==========")
        try:
            res = cloudstack.destroyVirtualMachine({'id': self.vm['id'], 'expunge': 'true'})
            self.checkJobStatus(res['jobid'], 0)

            while self.success < 0:
                continue

            if self.success:
                self.success = -1


        except KeyError as e:
            print("FAIL to call destroyVirtualMachine", e)



    def haTest(self):
        print("=============== HA Test ===============")

        # portForwarding vm
        print("\n========== PortForwarding ==========")
        try:
            nic = self.vm['nic']

            portForwardingRules = cloudstack.listPortForwardingRules({'networkid': nic[0]['networkid']})
            # print(portForwardingRules)

            usedPorts = [1080, 1194, 1900, 3306, 3479, 3480, 3690, 5228, 5353, 6379, 9100, 17500]

            print("========== current network's information ==========")
            for portForwardingRule in portForwardingRules:

                for i in range(int(portForwardingRule['publicport']), int(portForwardingRule['publicendport']) + 1):
                    usedPorts.append(i)

                print('')
                print('ipaddress: ' + portForwardingRule['ipaddress'])
                print('protocol: ' + portForwardingRule['protocol'])
                print('publicPortStart: ' + portForwardingRule['publicport'])
                print('publicPortEnd: ' + portForwardingRule['publicendport'])
                print('privatePortStart: ' + portForwardingRule['privateport'])
                print('privatePortEnd: ' + portForwardingRule['privateendport'])
                print('')

            while True:
                randPublicPort = random.randint(10000, 40000)

                for usedPort in usedPorts:
                    if randPublicPort == usedPort:
                        continue
                break

            # create portForwarding rule
            print("\n========== Create PortForwarding Rule ==========")
            try:
                resCp = cloudstack.createPortForwardingRule(
                    {'ipaddressid': 'c949cae5-5e0f-45cf-840c-fa3ae6804097', 'privateport': '22', 'protocol': 'TCP',
                     'publicport': str(randPublicPort), 'virtualmachineid': self.vm['id']})
                print('public port: ' + str(randPublicPort))
                print(resCp)

                # check if portForwarding was successful
                self.checkJobStatus(resCp['jobid'], 0)

                while self.success < 0:
                    continue

                if self.success:
                    self.success = -1

                    # HA Test start
                    print("\n========== HA Testing ==========")

                '''   
                # create firewall rule
                print("\n========== Create Firewall Rule ==========")

                try: 
                    resCf = cloudstack.createFirewallRule({'ipaddressid':'c949cae5-5e0f-45cf-840c-fa3ae6804097', 'protocol':'TCP', 'startport':str(randPublicPort)})
                    print('startport: ' + resCf['startport'])
                    print('id: ' + resCf['id'])



                except KeyError as e:
                    print("FAIL to call createFirewallRule", e)
            '''

            except KeyError as e:
                print("FAIL to call createPortForwardingRule", e)

        except KeyError as e:
            print("FAIL to call listPortForwardingRules", e)




    def migrateVM(self):
        # self.vms = cloudstack.listVirtualMachines()
        # storages = cloudstack.listStoragePools()

        print("=============== Migration ===============")

        vmid = self.vm['id']
        print('vm id: ' + vmid)
        print('')

        try:
            curVM = cloudstack.listVirtualMachines({'id': vmid})
            curHost = cloudstack.listHosts({'id': curVM[0]['hostid']})
            curCluster = cloudstack.listClusters({'id': curHost[0]['clusterid']})

            print("========== Current vm's information ==========")
            print("vm's Host: " + curHost[0]['name'])
            print("vm's Host id: " + curHost[0]['id'])
            print("vm's Cluster: " + curCluster[0]['name'])

        except KeyError as e:
            print("FAIL to call vm's information", e)

        print('')

        print("============== Enter host id ===================")

        try:
            hosts = cloudstack.listHosts({'virtualmachineid': vmid})

            for host in hosts:
                print("host id:" + host['id'] + " name:" + host['name'])

            print('')

            if len(hosts) <= 0:
                print("There is no host to migrate\n")
                return

            else:
                hostid = str(raw_input("host id: "))
                print('')

        except KeyError:
            print("FAIL to call listHosts")


        print("========== MIGRATION START ==========")

        # migrate the vm

        try:
            res = cloudstack.migrateVirtualMachine({'virtualmachineid': vmid, 'hostid': hostid})
            print(res)

            # check if migration was successful
            checkJobStatus(res['jobid'], 0)

            while self.success < 0:
                continue

            if self.success:
                self.success = -1

                try:
                    curVM = cloudstack.listVirtualMachines({'id': vmid})
                    curHost = cloudstack.listHosts({'id': curVM[0]['hostid']})
                    curCluster = cloudstack.listClusters({'id': curHost[0]['clusterid']})

                    print("========== After vm's information ==========")
                    print("vm's Host: " + curHost[0]['name'])
                    print("vm's Host id: " + curHost[0]['id'])
                    print("vm's Cluster: " + curCluster[0]['name'])

                except KeyError as e:
                    print("FAIL to call vm's information", e)

        except KeyError as e:
            print("FAIL to call migrateVirtualMachine", e)





    def checkVolume(self):
        #vols = cloudstack.listVolumes()  # Volume LIST

        # Volume Attach
        print("\n============== Attach =============")

        tar_vm_ID = self.vm['id']
        tar_vol_ID = self.volumeidForCheck

        # Start Volume Attach
        print("\n============== Processing ==============")
        tar_vols = cloudstack.listVolumes({"id": tar_vol_ID})

        # Original Volume Info
        for tar_vol in tar_vols:
            try:
                print("Before Volume's VM : %s" % (tar_vol['vmname']))
            except KeyError:
                print("Before Volume's VM : None")

        cloudstack.attachVolume({"id": tar_vol_ID, "virtualmachineid": tar_vm_ID})
        sleep(2)

        tar_vols = cloudstack.listVolumes({"id": tar_vol_ID})

        # Attached Volume Info
        for tar_vol in tar_vols:
            try:
                print("\nAfter Volume's VM : %s ! Attach Success" % (tar_vol['vmname']))
            except KeyError:
                print("\nAttach Fail")



        print("\n================= Detach ================")

        print("\n============== Processing ==============")

        # Original Volume Info
        tar_vols = cloudstack.listVolumes({"id": tar_vol_ID})
        for tar_vol in tar_vols:
            try:
                print("Before Volume's VM : %s" % (tar_vol['vmname']))
            except KeyError:
                print("Before Volume's VM : None")

        cloudstack.detachVolume({"id": tar_vol_ID})
        sleep(1)

        # Detached Volume Info
        tar_vols = cloudstack.listVolumes({"id": tar_vol_ID})
        for tar_vol in tar_vols:
            try:
                print("\nAfter Volume's VM : %s" % (tar_vol['vmname']))
            except KeyError:
                print("\nAfter Volume's VM : None ! detatch Success")



    def checkVMscale(self):
        #vms = cloudstack.listVirtualMachines()  # VM LIST
        #ser_ofrs = cloudstack.listServiceOfferings()  # Service Offering LIST

        print("\n============== Check VM Scale =============")


        print("\n============== Input Confirm ============")
        tar_vm_ID = self.vm['id']
        tar_ofr_ID = self.ServiceofferingidForScaleCheck

        # Start VM Scale in/out
        print("\n============== Processing ==============")

        tar_vms = cloudstack.listVirtualMachines({"id": tar_vm_ID})

        # Original VM Info
        for tar_vm in tar_vms:
            print("Before VM's Memory : %s" % (tar_vm['memory']))
            print("Before VM's CPUSpeed : %s" % (tar_vm['cpuspeed']))
            print("Before VM's CPUNumber : %s" % (tar_vm['cpunumber']))
            print("Before VM's Service Offering Name : %s" % (tar_vm['serviceofferingname']))

        # VM Scale in/out
        res = cloudstack.stopVirtualMachine({"id": tar_vm_ID})

        print(res)

        # check if deployment was successful
        self.checkJobStatus(res['jobid'], 0)

        while self.success < 0:
            continue

        if self.success:
            self.success = -1

            cloudstack.changeServiceForVirtualMachine({"id": tar_vm_ID, "serviceofferingid": tar_ofr_ID})

            tar_vms = cloudstack.listVirtualMachines({"id": tar_vm_ID})

            # Changed VM Info
            for tar_vm in tar_vms:
                print("\nAfter VM's Memory : %s" % (tar_vm['memory']))
                print("After VM's CPUSpeed : %s" % (tar_vm['cpuspeed']))
                print("After VM's CPUNumber : %s" % (tar_vm['cpunumber']))
                print("After VM's Service Offering Name : %s" % (tar_vm['serviceofferingname']))



        res = cloudstack.startVirtualMachine({"id": tar_vm_ID})
        print(res)

        # check if deployment was successful
        self.checkJobStatus(res['jobid'], 0)

        while self.success < 0:
            continue

        if self.success:
            self.success = -1


    def checkRevert(self):

        vols = cloudstack.listVolumes()  # VM LIST
        snps = cloudstack.listSnapshots()  # Snapshot LIST

        print
        "\n============== Volume LIST =============="
        for vol in vols:
            print
            "%s %s" % (vol['id'], vol['name'])

        print
        "\n============== Snapshot LIST ==========="
        for snp in snps:
            print
            "%s %s %s" % (snp['id'], snp['name'], snp['volumename'])

        print
        "\n============== FUNC ============="
        vol_name = raw_input("Target Volume Name : ")
        snp_name = raw_input("Created Snapshot Name : ")

        print
        "\n============== Input Confirm ============"
        tar_vol_ID = ''
        for vol in vols:
            if vol['name'] == vol_name:
                print
                "Volume : %s %s" % (vol['id'], vol['name'])
                tar_vol_ID = vol['id']

        print
        "\n============== Processing =============="
        cloudstack.createSnapshot({"volumeid": tar_vol_ID, "name": snp_name})
        snps = cloudstack.listSnapshots()
        snp_ID = ''

        # Snapshot Create Check (idx)
        idx = 0
        for snp in snps:
            if snp['name'] == snp_name:
                idx = 1
                snp_ID = snp['id']
            print
            "Snapshot Name : %s " % (snp['name'])

        if idx == 1:
            print
            "**** Snapshot Create Success ! ****"
        else:
            print
            "**** Snapshot Create Fail ****"

        ''' Volume Delete (431 Error)
        cloudstack.detachVolume({"id":tar_vol_ID})
        cloudstack.deleteVolume({"id":tar_vol_ID})
        vols = cloudstack.listVolumes()

        idx = 0
        for vol in vols :
        if vol['id'] == tar_vol_ID :
        print "\n**** Volume Delete Fail ****"
        idx = 1

        if idx == 0 :
        print "\n**** Volume Delete Success! ****"

        '''

        # Revert Volume Check(idx)
        vol_name = raw_input("\n Reverted Volume Name : ")
        cloudstack.createVolume({"snapshotid": snp_ID, "name": vol_name})

        vols = cloudstack.listVolumes()
        idx = 0

        print
        "\n~~~~~~~~~~ Volume List ~~~~~~~~~~~"
        for vol in vols:
            if vol['name'] == vol_name:
                idx = 1
            print
            "vol name : %s" % (vol['name'])
        print
        "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"

        if idx == 1:
            print
            "\n**** Volume Revert Success ****!"
        else:
            print
            "\n**** Volume Revert Fail ****"


if __name__ == "__main__":

    test1 = Function_Test()
    test1.deployVM()
    #test1.checkRevert()
    test1.checkVMscale()
    test1.checkVolume()
    test1.distroyVM()

