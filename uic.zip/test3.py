# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'test.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui, QtDesigner
import CloudStack


api = 'http://10.12.0.144:8080/client/api'
apikey = '9GTbaO-M4U7CCb58ztsK18VrTnMzGExJ5TF-y6hzhn26SsIMYsjjJpYONQ10TYpRoGX3BrnPCdGwz7ePz9JxzA'
secret = 'KRB1lri1TiL8orU-htRa01yRa5_rvxk6WbrSRzF8LmJHSF6ygag9ASAL2qui4oqIDxIPein7ub08Bg7k-9mpdQ'
cloudstack = CloudStack.Client(api, apikey, secret)

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):

    def __init__(self):
        self.zones = ['epc-expr-kr-0']
        self.computeOfferings = cloudstack.listServiceOfferings()
        self.diskOfferings = ['No Thanks', 'Small', 'Medium', 'Large']
        self.templates = ''
        self.networks = ''

        self.seleted_zone = ''
        self.seleted_template = ''
        self.seleted_computeOffering = ''
        self.seleted_diskOffering = ''

    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(360, 304)

        self.verticalLayout_2 = QtGui.QVBoxLayout(Dialog)
        self.verticalLayout_2.setObjectName(_fromUtf8("verticalLayout_2"))
        self.wgt_type = QtGui.QTabWidget(Dialog)
        self.wgt_type.setObjectName(_fromUtf8("wgt_type"))

        self.tab_vm = QtGui.QWidget()
        self.tab_vm.setObjectName(_fromUtf8("tab_vm"))
        self.verticalLayout = QtGui.QVBoxLayout(self.tab_vm)
        self.verticalLayout.setObjectName(_fromUtf8("verticalLayout"))
        self.lay_testType = QtGui.QHBoxLayout()
        self.lay_testType.setSizeConstraint(QtGui.QLayout.SetDefaultConstraint)
        self.lay_testType.setObjectName(_fromUtf8("lay_testType"))

        self.check_function = QtGui.QCheckBox(self.tab_vm)
        self.check_function.setMinimumSize(QtCore.QSize(87, 17))
        self.check_function.setBaseSize(QtCore.QSize(0, 0))
        self.check_function.setObjectName(_fromUtf8("check_function"))
        self.lay_testType.addWidget(self.check_function)

        self.check_performance = QtGui.QCheckBox(self.tab_vm)
        self.check_performance.setEnabled(True)
        self.check_performance.setMinimumSize(QtCore.QSize(87, 17))
        self.check_performance.setObjectName(_fromUtf8("check_performance"))
        self.lay_testType.addWidget(self.check_performance)

        self.verticalLayout.addLayout(self.lay_testType)
        self.lay_vmInfo = QtGui.QFormLayout()
        self.lay_vmInfo.setFieldGrowthPolicy(QtGui.QFormLayout.ExpandingFieldsGrow)
        self.lay_vmInfo.setContentsMargins(-1, 10, -1, -1)
        self.lay_vmInfo.setVerticalSpacing(20)
        self.lay_vmInfo.setObjectName(_fromUtf8("lay_vmInfo"))

        self.label_zone = QtGui.QLabel(self.tab_vm)
        self.label_zone.setObjectName(_fromUtf8("label_zone"))
        self.lay_vmInfo.setWidget(0, QtGui.QFormLayout.LabelRole, self.label_zone)

        self.label_template = QtGui.QLabel(self.tab_vm)
        self.label_template.setObjectName(_fromUtf8("label_template"))
        self.lay_vmInfo.setWidget(1, QtGui.QFormLayout.LabelRole, self.label_template)

        self.label_computeOf = QtGui.QLabel(self.tab_vm)
        self.label_computeOf.setObjectName(_fromUtf8("label_computeOf"))
        self.lay_vmInfo.setWidget(2, QtGui.QFormLayout.LabelRole, self.label_computeOf)

        self.label_diskOf = QtGui.QLabel(self.tab_vm)
        self.label_diskOf.setObjectName(_fromUtf8("label_diskOf"))
        self.lay_vmInfo.setWidget(3, QtGui.QFormLayout.LabelRole, self.label_diskOf)

        self.label_network = QtGui.QLabel(self.tab_vm)
        self.label_network.setObjectName(_fromUtf8("label_network"))
        self.lay_vmInfo.setWidget(4, QtGui.QFormLayout.LabelRole, self.label_network)

        self.combo_zone = QtGui.QComboBox(self.tab_vm)
        self.combo_zone.addItems(self.zones)

        sizePolicy = QtGui.QSizePolicy(QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.combo_zone.sizePolicy().hasHeightForWidth())
        self.combo_zone.setSizePolicy(sizePolicy)
        self.combo_zone.setObjectName(_fromUtf8("combo_zone"))
        self.lay_vmInfo.setWidget(0, QtGui.QFormLayout.FieldRole, self.combo_zone)

        self.combo_computeOf = QtGui.QComboBox(self.tab_vm)
        sizePolicy.setHeightForWidth(self.combo_computeOf.sizePolicy().hasHeightForWidth())
        self.combo_computeOf.setSizePolicy(sizePolicy)
        self.combo_computeOf.setObjectName(_fromUtf8("combo_computeOf"))
        self.lay_vmInfo.setWidget(2, QtGui.QFormLayout.FieldRole, self.combo_computeOf)

        self.combo_diskOf = QtGui.QComboBox(self.tab_vm)
        sizePolicy.setHeightForWidth(self.combo_diskOf.sizePolicy().hasHeightForWidth())
        self.combo_diskOf.setSizePolicy(sizePolicy)
        self.combo_diskOf.setObjectName(_fromUtf8("combo_diskOf"))
        self.lay_vmInfo.setWidget(3, QtGui.QFormLayout.FieldRole, self.combo_diskOf)

        self.combo_template = QtGui.QComboBox(self.tab_vm)
        sizePolicy.setHeightForWidth(self.combo_template.sizePolicy().hasHeightForWidth())
        self.combo_template.setSizePolicy(sizePolicy)
        self.combo_template.setObjectName(_fromUtf8("combo_template"))
        self.lay_vmInfo.setWidget(1, QtGui.QFormLayout.FieldRole, self.combo_template)

        self.combo_network = QtGui.QComboBox(self.tab_vm)
        sizePolicy.setHeightForWidth(self.combo_network.sizePolicy().hasHeightForWidth())
        self.combo_network.setSizePolicy(sizePolicy)
        self.combo_network.setObjectName(_fromUtf8("combo_network"))
        self.lay_vmInfo.setWidget(4, QtGui.QFormLayout.FieldRole, self.combo_network)

        self.verticalLayout.addLayout(self.lay_vmInfo)
        self.wgt_type.addTab(self.tab_vm, _fromUtf8(""))

        self.tab_gpu = QtGui.QWidget()
        self.tab_gpu.setObjectName(_fromUtf8("tab_gpu"))
        self.wgt_type.addTab(self.tab_gpu, _fromUtf8(""))
        self.verticalLayout_2.addWidget(self.wgt_type)
        self.tab_history = QtGui.QWidget()
        self.tab_history.setObjectName(_fromUtf8("tab_history"))
        self.wgt_type.addTab(self.tab_history, _fromUtf8(""))

        self.btn_confirm = QtGui.QDialogButtonBox(Dialog)
        self.btn_confirm.setOrientation(QtCore.Qt.Horizontal)
        self.btn_confirm.setStandardButtons(QtGui.QDialogButtonBox.Cancel|QtGui.QDialogButtonBox.Ok)
        self.btn_confirm.setObjectName(_fromUtf8("btn_confirm"))
        self.verticalLayout_2.addWidget(self.btn_confirm)

        self.retranslateUi(Dialog)
        self.wgt_type.setCurrentIndex(0)
        QtCore.QObject.connect(self.btn_confirm, QtCore.SIGNAL(_fromUtf8("accepted()")), Dialog.accept)
        QtCore.QObject.connect(self.btn_confirm, QtCore.SIGNAL(_fromUtf8("rejected()")), Dialog.reject)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

        # Connect function to "zone" combo box
        self.combo_zone.currentIndexChanged.connect(self.loadComboBoxText)

        # if 'accept' is clicked, launch a new window

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))

        self.check_function.setText(_translate("Dialog", "Function", None))
        self.check_performance.setText(_translate("Dialog", "Performance", None))

        self.label_zone.setText(_translate("Dialog", "Zone :", None))
        self.label_template.setText(_translate("Dialog", "Template :", None))
        self.label_computeOf.setText(_translate("Dialog", "Compute Offering :", None))
        self.label_diskOf.setText(_translate("Dialog", "Disk Offering :", None))
        self.label_network.setText(_translate("Dialog", "Network :", None))

        self.wgt_type.setTabText(self.wgt_type.indexOf(self.tab_vm), _translate("Dialog", "VM", None))
        self.wgt_type.setTabText(self.wgt_type.indexOf(self.tab_gpu), _translate("Dialog", "GPU", None))

    # Load texts in combo boxes
    def loadComboBoxText(self):
        print("loadComboBoxText")
        print(str(self.combo_zone.currentText()))

        if str(self.combo_zone.currentText()) == 'epc-expr-kr-0':
            print("loadComboBoxText -  str(self.combo_zone.currentText()) is 'epc-expr-kr-0'")
            self.seleted_zone = '7327e4c4-3b7e-408e-a7f2-eec586ec93ee';
            self.templates = cloudstack.listTemplates({'templatefilter': 'executable', 'zoneid': self.seleted_zone})
            self.networks = cloudstack.listNetworks({'zoneid': self.seleted_zone})

            self.clearComboBoxItem()
            self.addComboBoxItem()

    def clearComboBoxItem(self):
        print("clearComboBoxItem")
        self.combo_network.clear()
        self.combo_template.clear()
        self.combo_computeOf.clear()
        self.combo_diskOf.clear()

    def addComboBoxItem(self):
        print("addComboBoxItem")

        for diskOffering in self.diskOfferings:
            self.combo_diskOf.addItem(diskOffering)

        for network in self.networks:
            self.combo_network.addItem(str(network['name']))

        for template in self.templates:
            self.combo_template.addItem(str(template['name']))

        for computeOffering in self.computeOfferings:
            self.combo_computeOf.addItem(str(computeOffering['name']))


    # Start test
    def startTest(self):
        return

    import sys
    app = QtGui.QApplication(sys.argv)
    Dialog = QtGui.QDialog()

    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()

    sys.exit(app.exec_())
