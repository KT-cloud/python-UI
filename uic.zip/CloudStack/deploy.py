import Client

Client.deployVirtualMachine("serviceofferingid": ,"templateid":,"zoneid":,"account": , "diskofferingid":)
